How-to-root Samsung xCover3 - Lollipop
Root Installation developed by @Matt07211

Disclaimer: Anything you do with your own phone is done at your own risk.
Don't complain if you accidentally brick your phone. Fix it by using
Google, flash back stock firmware or post on XDA for help.

Knox will be voided, and so will your warranty.

We cannot say what works for us, may or may not work for you.
Good luck :)

Prerequisites:
- ADB Installed
- USB Debugging Enabled
- Samsung USB Drivers Installed
- Samsung ODIN (Perferably Odin3_v3.10.7 or above)
- A Brain that can use common sense, or Google.

To-Do:
- Create a su.img that is compatibily with apps that have Hardcoded su paths,
this means these types of apps won't work with systemless (I'm looking at you
ES File Explorer), this add a compatibility layer allowing for them apps to
work.
- Create a working TWRP for this Device (Samsung xCover 3 - Lollipop), but
I'm severly Internet Limited, so may not happen any time soon.


Installation:
1) Make sure you have the prerequisites installed, and "xcover3-lollipop-root.zip"
unzipped. Then type

adb devices

to make sure adb recognises the phone and that its authorized.

2) Type (or copy) exaclty as below. *Please be paitent, as the first command
takes about 20 seconds to complete.

adb push su.img /data/local/tmp
adb install Superuser.apk

3) Once thats completed, turn off the device and then boot into download 
mode (Volume Down + Home + Power). 

4) Open the ODIN program, click "AP" then navigate to the "boot.tar.md5"
file that is in the "xcover3-lollipop-root: folder, then click open/okay.
Click start to flash.

5) The phone should auto-reboot. Once its fully booted, reboot once more
(perferabbly twice), this is to allow the script placed in the ramdisk to
move the su.img to /data.

6) ...

7) Profit? Yay you've now got root. You can go and test it out by downloading
terminal emulator and typing "su", you then should be prompted to grant root
permissions to the app. Once granted, the "$" symbol will chnage to "#" to
signify root.

